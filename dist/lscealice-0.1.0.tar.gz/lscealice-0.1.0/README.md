# lsce-alice

Alice - a portable and versatile ALignment interface for (ICE)cores.
